#!/usr/bin/env python
# coding=utf-8
from sep_Pk import *

window_k= np.sinc(1./N*fn[:,None,None])*np.sinc(1./N*fn[None,:,None])*np.sinc(1./N*fnc[None,None,:])
for i in np.arange(RunPk2Num):
    print 'Path In :',Path_Pk2_Input[i][0],Path_Pk2_Input[i][2]
    print 'Path out:',Path_Pk2_Output[i]
    IsHalo1=int(Path_Pk2_Input[i][1])
    IsHalo2=int(Path_Pk2_Input[i][3])
    delta1=Tide.LoadDataOfhdf5(Path_Pk2_Input[i][0])
    if IsHalo1:
        sum=delta1.sum()
        delta1*=(N**3/sum)
    delta2=Tide.LoadDataOfhdf5(Path_Pk2_Input[i][2])
    if IsHalo2:
        sum=delta2.sum()
        delta2*=(N**3/sum)
    deltak1=Tide.fft3d(delta1,nthreads)
    deltak2=Tide.fft3d(delta2,nthreads)
    result_pk=pk(delta1,delta2,window=window_k,nthreads=nthreads)
    Tide.SaveDataHdf5(result_pk,Path_Pk2_Output[i])
