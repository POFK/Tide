#!/bin/bash
num=$@
#python sep_checkDir.py   $num
#time mpirun -hostfile node_hostfile python sep_smooth.py    $num
#time mpirun -hostfile node_fat      python sep_wden.py      $num
#time mpirun -hostfile node_hostfile python sep_gamma.py     $num
#time mpirun -hostfile node_hostfile python sep_kappa_2d.py  $num
#time python sep_runPk.py                                    $num
#time mpirun -hostfile node_hostfile python sep_get_bin2d.py $num
time python get_wiener_bias.py $num
time mpirun -hostfile node_hostfile python sep_wkkappa.py   $num
time python sep_runPk2.py                                   $num
time python sep_run_bin1d.py $num
python plot_result.py $num
