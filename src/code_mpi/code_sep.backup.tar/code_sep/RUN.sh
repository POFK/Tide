#!/bin/bash
time ./sep_run.sh 10 &
sleep 1.5m
time ./sep_run.sh 11 &
sleep 1.5m
time ./sep_run.sh 12 &
sleep 1.5m
