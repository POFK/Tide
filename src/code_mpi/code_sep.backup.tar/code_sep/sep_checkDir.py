#!/usr/bin/env python
# coding=utf-8
from parameter import *
if not os.path.exists(dir):
    os.mkdir(dir)

