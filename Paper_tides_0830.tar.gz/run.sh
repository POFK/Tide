#!/bin/bash
./compile_tex.sh apstemplate
